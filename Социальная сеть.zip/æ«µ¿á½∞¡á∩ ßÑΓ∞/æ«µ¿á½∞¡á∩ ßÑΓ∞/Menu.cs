﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Социальная_сеть
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            GetInfo();
        }

        private void GetInfo()
        {
            try
            {
                MySqlConnection conn = DBUtils.GetDBConnection();
                MySqlDataAdapter adam = new MySqlDataAdapter("select * from auth;",conn);
                DataTable dt = new DataTable();
                conn.Open();
                adam.Fill(dt);
                dataGridView1.DataSource = dt;
                conn.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = DBUtils.GetDBConnection();
            string query = "delete from auth where id_login ="+textBox1.Text+";";
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader readdd;
            conn.Open();
            readdd = cmDB.ExecuteReader();
            conn.Close();
            try
            {
                MySqlConnection sql = DBUtils.GetDBConnection();
                MySqlDataAdapter adam = new MySqlDataAdapter("select * from auth;", sql);
                DataTable dt = new DataTable();
                conn.Open();
                adam.Fill(dt);
                dataGridView1.DataSource = dt;
                conn.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = DBUtils.GetDBConnection();
            string query = "update auth set login_pass ='"+textBox2.Text+"' where id_login ='" + textBox3.Text +"';";
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            MySqlDataReader readdd;
            conn.Open();
            readdd = cmDB.ExecuteReader();
            conn.Close();
            try
            {
                MySqlConnection sql = DBUtils.GetDBConnection();
                MySqlDataAdapter adam = new MySqlDataAdapter("select * from auth;", sql);
                DataTable dt = new DataTable();
                conn.Open();
                adam.Fill(dt);
                dataGridView1.DataSource = dt;
                conn.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }
    }
}
