﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Социальная_сеть
{
    public partial class Regictration : Form
    {
        public Regictration()
        {
            InitializeComponent();
        }
        

        public void button1_Click(object sender, EventArgs e)
        {
            if (passTB.Text == Retry.Text)
            {
                try
                {
                    string query = "insert into auth values(2, '"+login_box.Text+"', '"+passTB.Text+"');";
                    MySqlConnection conn = DBUtils.GetDBConnection();
                    MySqlCommand cmDB = new MySqlCommand(query, conn);
                    MySqlDataReader readdd;
                    conn.Open();
                    readdd = cmDB.ExecuteReader();
                    Menu Win = new Menu();
                    Win.Owner = this;
                    this.Hide();
                    Win.Show();
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
             }
             else MessageBox.Show("пароль не совпадает");
            

        }
    }
}
