﻿namespace Социальная_сеть
{
    partial class Regictration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.passL = new System.Windows.Forms.Label();
            this.passTB = new System.Windows.Forms.TextBox();
            this.loginL = new System.Windows.Forms.Label();
            this.login_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Retry = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // passL
            // 
            this.passL.AutoSize = true;
            this.passL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passL.Location = new System.Drawing.Point(13, 91);
            this.passL.Name = "passL";
            this.passL.Size = new System.Drawing.Size(67, 20);
            this.passL.TabIndex = 9;
            this.passL.Text = "Пароль";
            // 
            // passTB
            // 
            this.passTB.Location = new System.Drawing.Point(12, 114);
            this.passTB.Name = "passTB";
            this.passTB.Size = new System.Drawing.Size(205, 20);
            this.passTB.TabIndex = 8;
            // 
            // loginL
            // 
            this.loginL.AutoSize = true;
            this.loginL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loginL.Location = new System.Drawing.Point(13, 16);
            this.loginL.Name = "loginL";
            this.loginL.Size = new System.Drawing.Size(55, 20);
            this.loginL.TabIndex = 7;
            this.loginL.Text = "Логин";
            // 
            // login_box
            // 
            this.login_box.Location = new System.Drawing.Point(12, 39);
            this.login_box.Name = "login_box";
            this.login_box.Size = new System.Drawing.Size(205, 20);
            this.login_box.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(13, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Повторите пароль";
            // 
            // Retry
            // 
            this.Retry.Location = new System.Drawing.Point(12, 166);
            this.Retry.Name = "Retry";
            this.Retry.Size = new System.Drawing.Size(205, 20);
            this.Retry.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 192);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(236, 48);
            this.button1.TabIndex = 12;
            this.button1.Text = "Регистрация";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Regictration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 253);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Retry);
            this.Controls.Add(this.passL);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.loginL);
            this.Controls.Add(this.login_box);
            this.Name = "Regictration";
            this.Text = "Regictration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label passL;
        private System.Windows.Forms.TextBox passTB;
        private System.Windows.Forms.Label loginL;
        private System.Windows.Forms.TextBox login_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Retry;
        private System.Windows.Forms.Button button1;
    }
}