﻿namespace Социальная_сеть
{
    partial class Auth
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Enter = new System.Windows.Forms.Button();
            this.Exciting = new System.Windows.Forms.Button();
            this.loginL = new System.Windows.Forms.Label();
            this.passL = new System.Windows.Forms.Label();
            this.passTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.login_box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Enter
            // 
            this.Enter.Location = new System.Drawing.Point(149, 203);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(68, 30);
            this.Enter.TabIndex = 0;
            this.Enter.Text = "Вход";
            this.Enter.UseVisualStyleBackColor = true;
            this.Enter.Click += new System.EventHandler(this.button1_Click);
            // 
            // Exciting
            // 
            this.Exciting.Location = new System.Drawing.Point(12, 203);
            this.Exciting.Name = "Exciting";
            this.Exciting.Size = new System.Drawing.Size(68, 30);
            this.Exciting.TabIndex = 1;
            this.Exciting.Text = "Выход";
            this.Exciting.UseVisualStyleBackColor = true;
            this.Exciting.Click += new System.EventHandler(this.Exciting_Click);
            // 
            // loginL
            // 
            this.loginL.AutoSize = true;
            this.loginL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loginL.Location = new System.Drawing.Point(13, 13);
            this.loginL.Name = "loginL";
            this.loginL.Size = new System.Drawing.Size(55, 20);
            this.loginL.TabIndex = 3;
            this.loginL.Text = "Логин";
            // 
            // passL
            // 
            this.passL.AutoSize = true;
            this.passL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passL.Location = new System.Drawing.Point(13, 66);
            this.passL.Name = "passL";
            this.passL.Size = new System.Drawing.Size(67, 20);
            this.passL.TabIndex = 5;
            this.passL.Text = "Пароль";
            // 
            // passTB
            // 
            this.passTB.Location = new System.Drawing.Point(12, 89);
            this.passTB.Name = "passTB";
            this.passTB.Size = new System.Drawing.Size(205, 20);
            this.passTB.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(9, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Впервые? Зарегистрируйтесь!";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // login_box
            // 
            this.login_box.Location = new System.Drawing.Point(17, 37);
            this.login_box.Name = "login_box";
            this.login_box.Size = new System.Drawing.Size(200, 20);
            this.login_box.TabIndex = 7;
            // 
            // Auth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 245);
            this.Controls.Add(this.login_box);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passL);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.loginL);
            this.Controls.Add(this.Exciting);
            this.Controls.Add(this.Enter);
            this.Name = "Auth";
            this.Text = "Вход";
            this.Load += new System.EventHandler(this.Auth_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Enter;
        private System.Windows.Forms.Button Exciting;
        private System.Windows.Forms.Label loginL;
        private System.Windows.Forms.Label passL;
        private System.Windows.Forms.TextBox passTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox login_box;
    }
}

