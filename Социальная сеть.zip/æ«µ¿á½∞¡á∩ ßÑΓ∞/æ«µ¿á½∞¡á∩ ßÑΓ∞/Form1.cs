﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Социальная_сеть
{
    public partial class Auth : Form
    {
        public Auth()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT id_login FROM auth WHERE login_name = '" + login_box.Text + "' and login_pass = '" + passTB.Text + "';";
            MySqlConnection conn = DBUtils.GetDBConnection();
            MySqlCommand cmDB = new MySqlCommand(query, conn);
            try
            {
                conn.Open();
                int result = 0;
                result = Convert.ToInt32(cmDB.ExecuteScalar());
                if (result > 0)
                {
                    Menu Win = new Menu();
                    Win.Owner = this;
                    this.Hide();
                    Win.Show();
                    login_box.Clear();
                    passTB.Clear();
                }
                else MessageBox.Show("Возникла ошибка подключения!");
                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Возникла непредвиденная ошибка!"+Environment.NewLine+ex.Message);
            }
        }

        private void Exciting_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Regictration Win = new Regictration();
            Win.Owner = this;
            this.Hide();
            Win.Show();
        }

        private void Auth_Load(object sender, EventArgs e)
        {
            
        }
    }
}
